package array;
import java.util.Scanner;
public class Voltaje {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc= new Scanner(System.in);
		
		int voltaje[];
		int ta,vol,max,min,sum=0;
		double pro;
		
		System.out.println("Ingrese el tamaño del arreglo");
		ta=sc.nextInt();
		
		voltaje= new int [ta];
		
		for (int i=0;i<ta;i++) {
			System.out.println("Ingrese voltaje");
			vol=sc.nextInt();
			voltaje[i]=vol;
			sum=sum+voltaje[i];
		}
		
		max=min=voltaje[0];
		
		for (int j=0;j<voltaje.length;j++) {
			if(voltaje[j]>max) {
				max=voltaje[j];
			}
			
			if(voltaje[j]<min) {
				min=voltaje[j];
			}
		}
		
		pro=sum/voltaje.length;
		
		System.out.println("Voltaje max: "+max);
		System.out.println("Voltaje min: "+min);
		System.out.println("Promedio : "+pro);

	}

}
