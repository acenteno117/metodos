package array;

import java.util.Scanner;

public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner tc= new Scanner(System.in);
		int vector[], n, num, suma;
	 	String nombre;
	 	
		System.out.println("Ingres el tamaño del arreglo");
		n=tc.nextInt();
		vector= new int[n];
		
		for(int i=0; i<n; i++) {
			System.out.println("Ingrese un valor!");
			 num=tc.nextInt();
			 vector[i]=num;
			 if(vector[i]<0) {
				 System.out.println("el elemento es negativo");
			 }
			 
		}
		
		for(int j=0; j<vector.length; j++) {
			System.out.println("los numeros que ingreso :"+vector[j]);
		}
	}

}
