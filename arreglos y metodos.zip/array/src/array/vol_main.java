package array;

import java.util.Scanner;

public class vol_main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scan = new Scanner(System.in);
		int [] vector;
		int n;
		float vol,mayor=0,menor=0,suma = 0,prom;
		System.out.println("Ingrese el tamaño del arreglo");
		n = scan.nextInt();
		vector = new int[n];
		for(int i =0 ; i<n; i++)
		{
			System.out.println("Ingrese el voltaje:");
			vol = scan.nextFloat();
			vector[i]= (int) vol;
			suma+=vector[i];
		}
		for(int j =0 ; j<vector.length;j++)
		{
			if(mayor<vector[j])
			{
				mayor = vector[j];
			}
		}
		mayor = menor;
		for(int k =0 ; k<vector.length;k++)
		{
			if(menor>vector[k])
			{
				menor=vector[k];
			}
		}
		prom=suma/n;
		System.out.println("El mayor voltaje es:"+mayor);
		System.out.println("El menor voltaje es"+menor);
		System.out.println("El promedio es: "+prom);
	}

}
