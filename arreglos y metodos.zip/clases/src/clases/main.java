package clases;

import java.io.IOException;
import java.util.Scanner;

public class main {

	public static void main(String[] args) throws InterruptedException, IOException {
		// TODO Auto-generated method stub
		int x, y;
		Scanner tc= new Scanner(System.in);
		System.out.println("Calcualr suma");
		System.out.println("Ingrese el primer valor");
		x=tc.nextInt();
		System.out.println("Ingrese el Segundo valor");
		y=tc.nextInt();
		
	System.out.println(suma(x,y));
	System.out.println(resta(x,y));

	}
	public static  int suma(int a, int b) {
		int suma=0;
		  suma=a+b;
		return suma;
	}
	
	public static  int resta(int a, int b) {
		int resta=0;
		resta=a-b;
		return resta;
	}
	
}
	
	
	
