package clases;

public class multipelementos {

	public static void main(String[] args) {
		int product=0;
		int a1[] = { 2, 5, -2};
        int a2[] = { 3, -5,1 }; 
        
        for (int i = 0; i < a1.length; i++) {
            
        	product=product+(a1[i] * a2[i]);
        }
        
        System.out.println("el producto punto es: " +product);

	}

}
