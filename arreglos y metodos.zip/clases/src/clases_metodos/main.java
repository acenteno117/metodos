package clases_metodos;

import java.io.PrintStream;
import java.util.Scanner;

public class main {

	public static void main(String[] args) {
		operaciones op= new operaciones();
		int x, y;
		Scanner tc= new Scanner(System.in);
		System.out.println("Calcualr suma");
		System.out.println("Ingrese el primer valor");
		x=tc.nextInt();
		System.out.println("Ingrese el Segundo valor");
		y=tc.nextInt();
		
		System.out.println(op.multiplicacion(x, y));
		
	}
	
}
