package clases_metodos;

import java.io.IOException;

public class operaciones {
 
		
		public static  int multiplicacion(int a, int b) {
			int multi=0;
			multi=a*b;
			return multi;
		}
		
		public static  int division(int a, int b) {
			int div=0;
			div=a/b;
			return div;
		}
		
		public static void Limpiar() throws InterruptedException, IOException {
			
			 new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
		}

	 

}
